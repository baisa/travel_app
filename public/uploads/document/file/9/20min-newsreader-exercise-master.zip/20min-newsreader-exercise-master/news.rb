# TODO: 1. Create the news class
# TODO: 2. Add a constructor which has the 'id' and the 'item' as arguments
# TODO: 3. Add a method which returns the ID
# TODO: 4. Add a method which returns the title of the item
# TODO: 5. Add a method which returns the description of the item
# TODO: 6. Add a method which returns the publication date of the item
# TODO: 7. Add a method which returns the link of the item
