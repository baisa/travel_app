# 20min NewsReader Exercise

In case you get stuck anywhere, don’t be afraid to ask the coaches! They are here to help and will gladly explain everything to you! Take notes during the exercises. Even if you never look at them again, they will help you memorise things!

## Tasks
The tasks are listed as TODO comments in the source code files.
